package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class PurchaseDiscountController {
	public final String REGULAR_CUST_TYPE = "Regular";
	public final String PREMIUM_CUST_TYPE = "Premium";
	
	@RequestMapping(value="discount", method=RequestMethod.POST)
	@ResponseBody
	CustomerOutput getDiscount(@RequestBody CustomerInput customerInput) {
		CustomerOutput customerOutput = new CustomerOutput();
		String cust_type = customerInput.getCustType();
		double discount = 0;
		double purchase_amount = customerInput.getPurchaseAmount();
		double billing_amount = 0;
		if(cust_type.equals(REGULAR_CUST_TYPE)) {
			if(purchase_amount < 5000) {
				customerOutput.setBillingAmount(purchase_amount);
				customerOutput.setPurchaseAmount(purchase_amount);
				customerOutput.setCustType(cust_type);
			}
			else if(purchase_amount >= 5000 && purchase_amount <10000) {
				discount = purchase_amount * 10/100;
				billing_amount = purchase_amount - discount;
				customerOutput.setBillingAmount(billing_amount);
				customerOutput.setPurchaseAmount(purchase_amount);
				customerOutput.setCustType(cust_type);
				
			} else if(purchase_amount >= 10000) {
				discount = purchase_amount * 20/100;
				billing_amount = purchase_amount - discount;
				customerOutput.setBillingAmount(billing_amount);
				customerOutput.setPurchaseAmount(purchase_amount);
				customerOutput.setCustType(cust_type);
				
			}
		}else if(cust_type.equals(PREMIUM_CUST_TYPE)) {

			if(purchase_amount < 4000) {
				discount = purchase_amount * 10/100;
				billing_amount = purchase_amount - discount;
				customerOutput.setBillingAmount(billing_amount);
				customerOutput.setPurchaseAmount(purchase_amount);
				customerOutput.setCustType(cust_type);
			}
			else if(purchase_amount >= 4000 && purchase_amount <8000) {
				discount = purchase_amount * 15/100;
				billing_amount = purchase_amount - discount;
				customerOutput.setBillingAmount(billing_amount);
				customerOutput.setPurchaseAmount(purchase_amount);
				customerOutput.setCustType(cust_type);
				
			}else if(purchase_amount >= 8000 && purchase_amount <12000) {
				discount = purchase_amount * 20/100;
				billing_amount = purchase_amount - discount;
				customerOutput.setBillingAmount(billing_amount);
				customerOutput.setPurchaseAmount(purchase_amount);
				customerOutput.setCustType(cust_type);
				
			} else if(purchase_amount >= 12000) {
				discount = purchase_amount * 30/100;
				billing_amount = purchase_amount - discount;
				customerOutput.setBillingAmount(billing_amount);
				customerOutput.setPurchaseAmount(purchase_amount);
				customerOutput.setCustType(cust_type);
				
			}
		
		}
		return customerOutput;
	}
}
